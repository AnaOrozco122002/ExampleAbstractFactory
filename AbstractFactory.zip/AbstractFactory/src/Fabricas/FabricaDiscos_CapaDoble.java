package Fabricas;

import Productos.*;

public class FabricaDiscos_CapaDoble implements FabricaDiscos{

	@Override
	public BlueRay crearBlueRay() {
		return new BlueRay_CapaDoble();
	}

	@Override
	public DVD crearDVD() {
		return new DVD_CapaDoble();
	}
	
}

