package Fabricas;

import Productos.*;

public class FabricaDiscos_CapaSimple implements FabricaDiscos{

	@Override
	public BlueRay crearBlueRay() {
		return new BlueRay_CapaSimple();
	}

	@Override
	public DVD crearDVD() {
		return new DVD_CapaSimple();
	}
	
}
