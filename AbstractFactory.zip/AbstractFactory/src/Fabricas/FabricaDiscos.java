
package Fabricas;
import Productos.*;


public interface FabricaDiscos {
	public BlueRay crearBlueRay();
    public DVD crearDVD();
}
