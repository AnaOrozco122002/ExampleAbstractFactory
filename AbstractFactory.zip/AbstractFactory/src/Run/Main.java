package Run;
import Fabricas.*;
import Productos.*;
public class Main {

	public static void main(String[] args) {
		
		FabricaDiscos fabrica;
		DVD dvd;
		BlueRay blueray;

		fabrica = new FabricaDiscos_CapaSimple();
		dvd = fabrica.crearDVD();
		blueray = fabrica.crearBlueRay();

		System.out.println(dvd);
		System.out.println(blueray);

		fabrica = new FabricaDiscos_CapaDoble();
		dvd = fabrica.crearDVD();
		blueray = fabrica.crearBlueRay();

		System.out.println(dvd);
		System.out.println(blueray);

	}

}

