package Productos;

public class DVD_CapaSimple extends DVD {

	@Override
	public String getCapacidad() {
		return "4.7GB";
	}

	@Override
	public String getNombre() {
		return "DVD Capa Simple";
	}

	@Override
	public String getPrecio() {
		return "5.00$";
	}

	@Override
	public String toString() {
		return super.toString();
	}

	@Override
	public String getColor() {
		return "Blanco";
	}
	
}
