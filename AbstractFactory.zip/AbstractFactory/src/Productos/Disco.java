package Productos;

public abstract class Disco{

    public abstract String getCapacidad();

    public abstract String getNombre();

    public abstract String getPrecio();

    public String toString() {
            return getNombre() + " (" + getCapacidad() + ")";
    }
}
