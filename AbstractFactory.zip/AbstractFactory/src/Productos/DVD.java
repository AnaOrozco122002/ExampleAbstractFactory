package Productos;

public abstract class DVD extends Disco {

	@Override
	public String getCapacidad() {
		return null;
	}

	@Override
	public String getNombre() {
		return null;
	}

	@Override
	public String getPrecio() {
		return null;
	}

	@Override
	public String toString() {
		return super.toString();
	}
	
	public String getColor() {
		return null;
	}	
}
