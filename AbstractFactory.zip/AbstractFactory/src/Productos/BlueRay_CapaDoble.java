package Productos;

public class BlueRay_CapaDoble extends BlueRay {

	@Override
	public String getCapacidad() {
		return "50GB";
	}

	@Override
	public String getNombre() {
		return "BlueRay Capa Doble";
	}

	@Override
	public String getPrecio() {
		return "40.00$";
	}

	@Override
	public String toString() {
		return super.toString();
	}

	@Override
	public String getNumero() {
		return "456";
	}
}
