package Productos;

public class BlueRay_CapaSimple extends BlueRay {

	@Override
	public String getCapacidad() {
		return "25GB";
	}

	@Override
	public String getNombre() {
		return "BlueRay Capa Simple";
	}

	@Override
	public String getPrecio() {
		return "20.00$";
	}

	@Override
	public String toString() {
		return super.toString();
	}

	@Override
	public String getNumero() {
		return "123";
	}
}
